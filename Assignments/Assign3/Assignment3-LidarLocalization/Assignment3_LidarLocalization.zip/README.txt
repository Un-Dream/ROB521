see the files ass2_q1.m and ass2_q2.m for your assignment
