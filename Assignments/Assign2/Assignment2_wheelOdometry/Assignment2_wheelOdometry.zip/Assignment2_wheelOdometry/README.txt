see the file ass1.m for your assignment
